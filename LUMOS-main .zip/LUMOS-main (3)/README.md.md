computer organization - spring 2024
_______________________________________________
Iran university of science and technology
_______________________________________________
Assignment 2:Light Utilization with Multicycle Operational Stages (LUMOS) RISC-V Processor
Name: zeinab irannejad
Team members: Negar aliabadi farahani
Student ID:99400017
Date:2/07/2024
Report

Introduction:
The purpose of this project is to examine the multi-cycle components of a RISC-V processor and add a fixed-point arithmetic unit using the LUMOS RISC-V processor core.

Table of Contents:
- Explanation of hardware code (operation of multiplication, SQRT, Sponge unit, output)
- Explanation of assembly code
- Output images

In the HDL (Verilog) code, two instructions for multiplying fixed-point numbers and calculating their square root are implemented. In the `Fixed-point-unit`, the parameters are defined. The `WIDTH` parameter indicates the total number, with the processor we're working on being 32-bit. The `FBITS` parameter shows that the lower 10 bits are the fractional part, and the remaining 22 bits are the integer part.

Inputs include `Operand-1`, `Operand-2`, `Operation`, `result`, and `ready`. When `ready` becomes one, computations are complete. There is an `always` block sensitive to the rising edge of `reset`. If `reset` is one, `ready` is set to zero. Note that for synthesis, the `always` block should be removed, but since we are performing a simulation, this is not important. In line 420, an `always` block sensitive to the asterisk (combinational circuit) is implemented, acting as a multiplexer. For example, if `Operation` equals `Fpu-Mul`, it assigns `product` to `result` from `WIDTH+FBITS` to `FBITS`, sets `ready` directly to one, and assigns a signal called `Product-ready`. Similarly, for `Fpu-SQRT`, it follows the same logic. If none of these, it assigns high impedance to `result` and sets `ready` to zero.

### Code Illustration:
In the `Fpu-Mul` section, we assign `Product [WIDTH+FBITS-1:FBITS]` to `result` because multiplying two n-bit numbers results in a maximum of 2n-bit product. Hence, the `product` register signal is defined as 64-bit, while the final module output is 32-bit. Therefore, 32 bits are selected from the 64-bit result. The calculation is approximate, as mathematically, multiplying two decimal numbers each with 3 decimal places results in a product with 6 decimal places. Thus, the product will have 44 integer bits and 20 decimal bits. From bit 0 to 19 is the decimal part, and from 20 to 63 is the integer part. The decimal point, bit 20, is considered the origin, selecting 10 bits to the right and 22 bits from the integer part, from bit 10 to 41.

### Multiplication Operation:
The calculation method uses state machines (FSM). Several states are defined to create an FSM. An `initial` block is used for initial values, setting `Ready`, `product`, defined project registers, and `busy` to zero, and `Multiplayer-state` and `next-state` to `idle_state`.

### Code Illustration:
There are combinational and sequential circuits, an `always` block sensitive to the asterisk and clock with corresponding states. Always, at each clock, `state` is set to `next-state`, and by default `ready` is zero, becoming one for one clock cycle when the product is ready.

In line 398, `busy` is zero and must be set to one in the next line to trigger the `if` condition in the following clock cycle.

###Code Illustration:
Returning to line 276, the `always` block sensitive to the asterisk: In `first_state`, we assign `operand_1` and `operand_2` to the multiplier module inputs, allowing multiplication between clock edges. The process continues similarly in other states. For instance, in `second_state`, `operand_1`'s high part is assigned, in `third_state` the low part of `operand_1` and the high part of `operand_2` are assigned, and in `fourth_state`, both are assigned high.

Finally, the four partial products are accumulated in `product`.

SQRT:
The FSM logic is similar to multiplication. Initially, we identify the most significant bit to construct a counter based on dividing the number by two bits. The `root_calculator_temp` is ORed with 32 zero bits for `operand_1`, as `operand` may not be 32-bit. A `for` loop determines the bit-length of the number. Bit zero indicates even or odd, and in line 162, if the number is odd, it is incremented by one.

###Code Illustration:
According to the project algorithm, two high bits are separated and subtracted. The first subtraction equals the previous result (initially zero) plus two bits. This process continues until reaching the `result_state`.

Sponge Unit:
In this module, `scale time` and `define` are added initially. This module has no inputs or outputs, with several variables and parameters defined. An `initial` block generates the clock.

Output:
Between clock cycles 4 and 5, `operand` values change, preparing for square root calculation, and multiplication stops. The tested number results as expected. For square root, the output is very accurate.

Assembly Code Explanation:
The `Li` instruction loads the value of `coo` into `Sp` (register number 2), marking the data starting point. The `Addi` instruction adds 392 to `gp Sp`, followed by a `100p` instruction where `Flw` adds `Sp` to zero and loads into `F1`. Then, `FMUL` multiplies `F1` by `F2`, computing according to the Pythagorean theorem, and `FSQRT` computes the square root.

The `addi` instruction increments `Sp` by 8, skipping two numbers read. With 50 points, each represented by two numbers, the `blt` instruction loops back to `loop` if the first value is less than the second.

###Output Images:

